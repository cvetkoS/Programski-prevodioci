flex --noyywrap zadatak1a.l
gcc -o zadatak1a lex.yy.c -l l
./zadatak1a < br.txt
