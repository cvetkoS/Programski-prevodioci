flex --noyywrap zadatak1c.l
gcc -o zadatak1c lex.yy.c 
./zadatak1c < br.txt
