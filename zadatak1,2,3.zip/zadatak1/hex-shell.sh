flex --noyywrap zadatak1.l
gcc -o zadatak1 lex.yy.c -l l
./zadatak1 < br.txt
