flex --noyywrap zadatak3.l
gcc -o zadatak3 lex.yy.c -l l
./zadatak3
